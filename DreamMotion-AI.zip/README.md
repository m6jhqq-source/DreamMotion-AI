# DreamMotion AI

A responsive Arabic/English video-creation frontend with a small Node.js backend, prepared for Railway deployment.

## Important: what works now
- The web app UI, prompt form, reference-image upload UI, responsive layout, and gallery are implemented.
- The server runs in demo mode by default.
- **Real AI video generation is not enabled by default.** It requires a compatible video-generation inference endpoint and credentials. Free access, if any, depends on the provider's current quotas, model availability, and terms. This project does not promise unlimited free generation or 1080p/4K output.

## Run locally
```bash
npm install
npm start
```
Open http://localhost:3000

## Railway deployment
1. Create a new Railway project and deploy this folder from a GitHub repository.
2. Railway detects `package.json` and runs `npm start`.
3. Optional persistent storage is recommended for `/data` and `/public/uploads`; otherwise files may be lost on redeploy depending on the hosting configuration.

## Optional provider integration
The backend contains a basic Hugging Face-compatible endpoint adapter. To enable it, set:
- `VIDEO_PROVIDER=huggingface`
- `HF_TOKEN=...`
- `HF_MODEL_URL=https://...`

Not every Hugging Face model supports text-to-video through the generic `inputs` API. Check the selected model's documented request/response schema and adapt `server.js` accordingly. Never expose provider tokens in frontend JavaScript or commit them to Git.

## Free-tier notes
Railway and AI inference providers can change their free allowances and may require payment details. Verify current plan limits before deploying. This repository is a prepared application, not a deployed public website.
